module.exports = {
    stockTwitsEmail: "youremail@gmail.com",
    stockTwitsPassword: "your-password"
}